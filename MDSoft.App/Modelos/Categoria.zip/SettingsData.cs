﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tracking.Modelos
{
    public class SettingsData
    {
        public int Id { get; set; }
        public string urlApi { get; set; }

    }
}
